package demo;
import framework.MyScreen;
import framework.MyStage;

import org.lwjgl.opengl.XRandR.Screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

/**
 * 加载登录界面
 * 
 * @author i see
 * 
 */
public class LoginLoadScreen extends MyScreen {

	boolean load = false;

	@Override
	public void render(float delta) {
		if (load && MyGame.manager.update(500)) {
			load = false;


			game.setScreen(new LoginScreen());
			return;
		}

		stage.act();
		stage.draw();
	}

	@Override
	public void show() {

		stage = new MyStage();

		Gdx.app.postRunnable(new Runnable() {

			@Override
			public void run() {

				loading();
				load = true;
			}
		});

	}

	public void loading() {
	}


}
