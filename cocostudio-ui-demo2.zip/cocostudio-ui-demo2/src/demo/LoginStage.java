package demo;

import framework.CommonStage;
import cocostudio.ui.CocoStudioUIEditor;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputEvent.Type;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

/**
 * 登录界面界面
 * 
 * @author i see
 * 
 */
public class LoginStage extends CommonStage {

	public LoginStage() {
		init();
	}

	@Override
	public void init() {
//		CocoStudioUIEditor editer = new CocoStudioUIEditor(
//				Gdx.files.internal("head/DemoHead_UI.json"), null, null, null);
//		Group group = editer.createGroup();
//		addActor(group);

		CocoStudioUIEditor editer2 = new CocoStudioUIEditor(
				Gdx.files.internal("shop/DemoShop.json"), null);
		Group group2 = editer2.createGroup();
		addActor(group2);
	}
}
